#include "matvec583.hpp"
#ifdef __TEMPLATED
/* should be empty */

#else
/* If you are not using template, definitions of concrete functions go here */

#endif
